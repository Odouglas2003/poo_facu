#include "mapa.h"
#include <QPainter>

void Mapa::paintEvent( QPaintEvent * )  {
    QPainter painter( this );
    painter.drawLine( 0, 0, this->width(), this->height() );
    QImage im("C:/Users/checa/Documents/CV/THENER.png");
    painter.drawImage(0,0,im);
}
